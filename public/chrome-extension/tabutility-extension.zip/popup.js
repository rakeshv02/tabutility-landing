// Tabutility popup — lists the top 10 tools; each opens in a new tab.
const TOOLS = [
  { id: "uk-salary-calculator",          name: "Salary Calculator",   emoji: "\u{1F4B7}" },
  { id: "mortgage-calculator",           name: "Mortgage",            emoji: "\u{1F3E0}" },
  { id: "australian-tax-calculator",     name: "Income Tax",          emoji: "\u{1F9FE}" },
  { id: "percentage-calculator",         name: "Percentage",          emoji: "\u{1F4CA}" },
  { id: "tip-calculator",                name: "Tip & Bill Split",    emoji: "\u{1F37D}\u{FE0F}" },
  { id: "date-difference-calculator",    name: "Date Difference",     emoji: "\u{1F4C5}" },
  { id: "word-counter",                  name: "Word Counter",        emoji: "\u{1F4DD}" },
  { id: "json-formatter",                name: "JSON Formatter",      emoji: "\u{1F9F0}" },
  { id: "vat-calculator",                name: "VAT Calculator",      emoji: "\u{1F9FE}" },
  { id: "compound-interest-calculator",  name: "Compound Interest",   emoji: "\u{1F4C8}" }
];

const nav = document.getElementById("tools");
for (const t of TOOLS) {
  const a = document.createElement("a");
  a.className = "tool";
  a.href = `https://${t.id}.tabutility.com/?ref=extension`;
  a.innerHTML = `<span class="emoji"></span><span class="name"></span>`;
  a.querySelector(".emoji").textContent = t.emoji;
  a.querySelector(".name").textContent = t.name;
  a.addEventListener("click", (e) => {
    e.preventDefault();
    chrome.tabs.create({ url: a.href });
  });
  nav.appendChild(a);
}

document.getElementById("all-tools").addEventListener("click", (e) => {
  e.preventDefault();
  chrome.tabs.create({ url: e.currentTarget.href });
});
