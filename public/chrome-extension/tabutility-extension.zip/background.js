// Tabutility — Manifest V3 service worker.
// On install, open the welcome page once so users see what they got.
chrome.runtime.onInstalled.addListener((details) => {
  if (details.reason === "install") {
    chrome.tabs.create({ url: "https://tabutility.com/?ref=extension&event=install" });
  }
});
